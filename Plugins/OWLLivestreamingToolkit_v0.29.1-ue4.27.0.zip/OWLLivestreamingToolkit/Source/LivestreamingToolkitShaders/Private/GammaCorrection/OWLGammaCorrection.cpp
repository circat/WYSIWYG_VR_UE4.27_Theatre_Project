// Copyright Off World Live Limited, 2020-2021. All rights reserved.

#include "GammaCorrection/OWLGammaCorrection.h"

#include "CommonRenderResources.h"
#include "Shader.h"
#include "GlobalShader.h"
#include "SimpleElementShaders.h"
#include "ShaderParameterUtils.h"
#include "Engine/TextureRenderTarget2D.h"
#include "RHIStaticStates.h"
#include "Modules/ModuleManager.h"

class FOWLGammaCorrectionPS : public FGlobalShader
{
	DECLARE_SHADER_TYPE(FOWLGammaCorrectionPS,Global);

	static bool ShouldCompilePermutation(const FGlobalShaderPermutationParameters& Parameters)
	{
		return true;
	}

	/** Default constructor. */
	FOWLGammaCorrectionPS() {}

public:

	LAYOUT_FIELD(FShaderResourceParameter, SceneTexture);
	LAYOUT_FIELD(FShaderResourceParameter, SceneTextureSampler);
	LAYOUT_FIELD(FShaderParameter, InverseGamma);

	/** Initialization constructor. */
	FOWLGammaCorrectionPS(const ShaderMetaType::CompiledShaderInitializerType& Initializer)
		: FGlobalShader(Initializer)
	{
		SceneTexture.Bind(Initializer.ParameterMap,TEXT("SceneColorTexture"));
		SceneTextureSampler.Bind(Initializer.ParameterMap,TEXT("SceneColorTextureSampler"));
		InverseGamma.Bind(Initializer.ParameterMap,TEXT("InverseGamma"));
	}
};

class FOWLGammaCorrectionVS : public FGlobalShader
{
	DECLARE_SHADER_TYPE(FOWLGammaCorrectionVS,Global);

	static bool ShouldCompilePermutation(const FGlobalShaderPermutationParameters& Parameters)
	{
		return true;
	}

	/** Default constructor. */
	FOWLGammaCorrectionVS() {}

public:

	/** Initialization constructor. */
	FOWLGammaCorrectionVS(const ShaderMetaType::CompiledShaderInitializerType& Initializer)
		:	FGlobalShader(Initializer)
	{
	}
};

IMPLEMENT_SHADER_TYPE(,FOWLGammaCorrectionPS,TEXT("/Plugin/OWLLivestreamingToolkit/Private/OWLGammaCorrection.usf"),TEXT("MainPS"),SF_Pixel);
IMPLEMENT_SHADER_TYPE(,FOWLGammaCorrectionVS,TEXT("/Plugin/OWLLivestreamingToolkit/Private/OWLGammaCorrection.usf"),TEXT("MainVS"),SF_Vertex);

void FOWLGammaCorrection::Apply(
	UTextureRenderTarget2D* SourceRenderTarget,
	UTextureRenderTarget2D* DestinationRenderTarget,
	float Gamma)
{
	ENQUEUE_RENDER_COMMAND(CaptureCommand)(
		[
			SourceRenderTarget,
			DestinationRenderTarget,
			Gamma
		] (FRHICommandListImmediate& RHICmdList)
		{
			FOWLGammaCorrection::Apply_RenderThread(
				RHICmdList, 
				SourceRenderTarget,
				DestinationRenderTarget,
				Gamma);
		}
	);
}

void FOWLGammaCorrection::Apply_RenderThread(
		FRHICommandListImmediate& RHICmdList, 
		UTextureRenderTarget2D* SourceRenderTarget,
		UTextureRenderTarget2D* DestinationRenderTarget, 
		float Gamma)
{
	if(!SourceRenderTarget
		|| !SourceRenderTarget->GetRenderTargetResource()
		|| !SourceRenderTarget->GetRenderTargetResource()->GetRenderTargetTexture()
		|| !DestinationRenderTarget
		|| !DestinationRenderTarget->GetRenderTargetResource()
		|| !DestinationRenderTarget->GetRenderTargetResource()->GetRenderTargetTexture())
	{
		return;
	}
	const FTexture2DRHIRef& SrcTexture = SourceRenderTarget->GetRenderTargetResource()->GetRenderTargetTexture();
	const FTexture2DRHIRef& DstTexture = DestinationRenderTarget->GetRenderTargetResource()->GetRenderTargetTexture();
	
	FRHIRenderPassInfo RPInfo(DstTexture, ERenderTargetActions::Clear_Store);
	RHICmdList.BeginRenderPass(RPInfo, TEXT("OWLGammaCorrection"));
	SCOPED_DRAW_EVENT(RHICmdList, OWLGammaCorrection);
	FGraphicsPipelineStateInitializer GraphicsPSOInit;
	RHICmdList.ApplyCachedRenderTargets(GraphicsPSOInit);
	// turn off culling and blending
	GraphicsPSOInit.RasterizerState = TStaticRasterizerState<>::GetRHI();
	GraphicsPSOInit.BlendState = TStaticBlendState<>::GetRHI();
	// turn off depth reads/writes
	GraphicsPSOInit.DepthStencilState = TStaticDepthStencilState<false, CF_Always>::GetRHI();
	FGlobalShaderMap* ShaderMap = GetGlobalShaderMap(GMaxRHIFeatureLevel);
	TShaderMapRef<FOWLGammaCorrectionVS> VertexShader(ShaderMap);
	TShaderMapRef<FOWLGammaCorrectionPS> PixelShader(ShaderMap);
	GraphicsPSOInit.BoundShaderState.VertexDeclarationRHI = GFilterVertexDeclaration.VertexDeclarationRHI;
	GraphicsPSOInit.BoundShaderState.VertexShaderRHI = VertexShader.GetVertexShader();
	GraphicsPSOInit.BoundShaderState.PixelShaderRHI = PixelShader.GetPixelShader();
	GraphicsPSOInit.PrimitiveType = PT_TriangleList;
	SetGraphicsPipelineState(RHICmdList, GraphicsPSOInit);

	FRHIPixelShader* ShaderRHI = PixelShader.GetPixelShader();

	float InvDisplayGamma = Gamma = 0 ? 0.0f : 1.0f / Gamma; 
	
	if(SourceRenderTarget->RenderTargetFormat == ETextureRenderTargetFormat::RTF_RGBA8_SRGB)
	{
		InvDisplayGamma = 1.0f;
	}
	
	
	SetShaderValue(
		RHICmdList, 
		ShaderRHI,
		PixelShader->InverseGamma,
		InvDisplayGamma
		);
	
	SetTextureParameter(
		RHICmdList, 
		ShaderRHI,
		PixelShader->SceneTexture,
		PixelShader->SceneTextureSampler,
		TStaticSamplerState<SF_Bilinear>::GetRHI(),
		SrcTexture
		);

	IRendererModule* RendererModule = &FModuleManager::GetModuleChecked<IRendererModule>("Renderer");
	FIntPoint Res = DstTexture->GetTexture2D()->GetSizeXY();
	RendererModule->DrawRectangle(
		RHICmdList,
		0,0,
		Res.X,Res.Y,
		0,0,
		1,1,
		Res,
		FIntPoint(1,1),
		VertexShader,
		EDRF_Default);

	RHICmdList.EndRenderPass();
}
