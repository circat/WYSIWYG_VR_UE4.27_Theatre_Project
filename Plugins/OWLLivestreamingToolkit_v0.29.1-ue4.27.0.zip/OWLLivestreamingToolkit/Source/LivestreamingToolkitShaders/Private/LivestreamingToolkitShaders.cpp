// Copyright Off World Live Limited, 2020-2021. All rights reserved.

#include "LivestreamingToolkitShaders.h"
#include "Interfaces/IPluginManager.h"

#define LOCTEXT_NAMESPACE "FLivestreamingToolkitShadersModule"

void FLivestreamingToolkitShadersModule::StartupModule()
{
	FString PluginShaderDir = FPaths::Combine(IPluginManager::Get().FindPlugin(TEXT("OWLLivestreamingToolkit"))->GetBaseDir(), TEXT("Shaders"));
	AddShaderSourceDirectoryMapping(TEXT("/Plugin/OWLLivestreamingToolkit"), PluginShaderDir);
}

void FLivestreamingToolkitShadersModule::ShutdownModule(){}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FLivestreamingToolkitShadersModule, LivestreamingToolkitShaders)

