// Copyright Off World Live Limited, 2020-2021. All rights reserved.

#pragma once

#include "CoreMinimal.h"

class UTextureRenderTarget2D;
class FRHICommandListImmediate;

class LIVESTREAMINGTOOLKITSHADERS_API FOWLGammaCorrection
{
public:
	static void Apply(
		UTextureRenderTarget2D* SourceRenderTarget,
		UTextureRenderTarget2D* DestinationRenderTarget, 
		float Gamma
	);

private:
	static void Apply_RenderThread(
		FRHICommandListImmediate& RHICmdList, 
		UTextureRenderTarget2D* SourceRenderTarget,
		UTextureRenderTarget2D* DestinationRenderTarget, 
		float Gamma);
};

