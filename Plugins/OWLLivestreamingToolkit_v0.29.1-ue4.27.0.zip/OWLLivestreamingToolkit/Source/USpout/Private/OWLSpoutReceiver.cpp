﻿// Copyright Off World Live Limited, 2020-2021. All rights reserved.

#include "USpout/Public/OWLSpoutReceiver.h"
#include "SpoutModule.h"
#include "ClearQuad.h"
#include "SpoutDX.h"
#include "SpoutDX12/SpoutDX12.h"
#include "D3D12RHIPrivate.h"

void OWLSpoutReceiver::ReceiveRenderTarget(FString name, UTextureRenderTarget2D* textureRenderTarget2D, bool useFirstAvailableSender)
{
	if (FailedToInitialise) return;

	if(!Initialised)
	{
		FString rhiString = GDynamicRHI->GetName();
		RHIType = OWLSpoutTools::StringToRHIType(rhiString);

		if (RHIType == OWLSpoutTools::ERHIType::D3D11 || RHIType == OWLSpoutTools::ERHIType::D3D12)
		{
			InitDX();
		}
		else
		{
			FailedToInitialise = true;
			UE_LOG(OWLSpoutLog, Warning, TEXT("%s is incompatible with the Spout interface. Please use D3D11 or D3D12."), *rhiString);
		}
	}
	Receive(name, textureRenderTarget2D, useFirstAvailableSender);
}

bool OWLSpoutReceiver::InitDX()
{
	if(Initialised) return true;
	if (RHIType == OWLSpoutTools::ERHIType::D3D11)
	{
		if(!SenderNames_DX11) SenderNames_DX11 = new spoutSenderNames;
		ENQUEUE_RENDER_COMMAND(RHICmdList)(
	[this](FRHICommandListImmediate& RHICmdList)
			{
				Device11 = static_cast<ID3D11Device*>(GDynamicRHI->RHIGetNativeDevice());
				Device11->GetImmediateContext(&DeviceContext11);
			}
		);
		Initialised = true;
	}
	else if (RHIType == OWLSpoutTools::ERHIType::D3D12)
	{
		if (!Receiver_DX12)
		{
			Receiver_DX12 = new spoutDX12;
		}
		Initialised = Receiver_DX12->OpenDirectX12();
	}
	return Initialised;
}

void OWLSpoutReceiver::Receive(FString Name, UTextureRenderTarget2D* DestRenderTarget, bool useFirstAvailableSender)
{
	if (DestRenderTarget == nullptr
		|| DestRenderTarget->Resource == nullptr
		|| DestRenderTarget->Resource->TextureRHI == nullptr
		|| DestRenderTarget->Resource->TextureRHI->GetTexture2D() == nullptr
		|| !Initialised)
	{
		// this is a safety check in case user is regenerating the resource
		// for example this happens while resizing
		return;
	}
	
	if (RHIType == OWLSpoutTools::ERHIType::D3D11)
	{
		const FString ActualName = useFirstAvailableSender ? GetFirstAvailableName_DX11() : Name;
		// check if the name exist
		if (!SenderNames_DX11->FindSenderName(TCHAR_TO_ANSI(*ActualName)))
		{
			// if not clear and return early
			if (!AlreadyClear_DX11)
			{
				// no texture to receive so we clear render target
				DestRenderTarget->UpdateResourceImmediate(true);
				AlreadyClear_DX11 = true;
			}
			return;
		}

		unsigned int Width;
		unsigned int Height;
		HANDLE Handle;
		unsigned long Format;
		
		SenderNames_DX11->GetSenderInfo(TCHAR_TO_ANSI(*ActualName), Width, Height, Handle, Format);
		ETextureRenderTargetFormat RT_Format = GetRTFormatFromDX((DXGI_FORMAT)Format);
		UpdateDestRenderTargetIfNeeded(Width, Height, RT_Format, DestRenderTarget);
		
		if (!DestRenderTarget)
		{
			UE_LOG(OWLSpoutLog, Error, TEXT("Frame skipped: Receiving Render Target is being modified: %s"), *ActualName);
			return; 
		}
		
		ENQUEUE_RENDER_COMMAND(RHICmdList)(
		[this, Handle, ActualName, DestRenderTarget](FRHICommandListImmediate& RHICmdList)
			{
				if(!Receive_DX11_RT(ActualName, Handle, DestRenderTarget))
				{
					return;
				}
			}
		);
	}
	else if (RHIType == OWLSpoutTools::ERHIType::D3D12)
	{
		const FString ActualName = useFirstAvailableSender ? GetFirstAvailableName_DX12() : Name;
		if(!Receive_DX12(ActualName, DestRenderTarget))
		{
			return;
		}
	}
}

void OWLSpoutReceiver::UpdateDestRenderTargetIfNeeded(int Width, int Height, ETextureRenderTargetFormat Format, UTextureRenderTarget2D* Target)
{
	if (Target->GetSurfaceWidth() != Width
		|| Target->GetSurfaceHeight() != Height
		|| Target->RenderTargetFormat != Format)
	{
		Target->RenderTargetFormat = Format;
		Target->ResizeTarget(Width, Height);
		Target->UpdateResource();
	}
}

bool OWLSpoutReceiver::Receive_DX11_RT(FString name, HANDLE Handle, UTextureRenderTarget2D* DestRenderTarget)
{
	ID3D11Texture2D* ReceivedTexture;
	HRESULT hr = Device11->OpenSharedResource(Handle, __uuidof(ID3D11Resource), (void**)(&ReceivedTexture));
	if (FAILED(hr))
	{
		UE_LOG(OWLSpoutLog, Error, TEXT("Create Receiver: Failed while trying to open shared dx11 resource for receiver: %s"), *name);
		return false;
	}
	
	// copy
	FTexture2DRHIRef Target = DestRenderTarget->Resource->TextureRHI->GetTexture2D();
	ID3D11Texture2D* targetTex = (ID3D11Texture2D*)Target->GetNativeResource();
	DeviceContext11->CopyResource(targetTex, ReceivedTexture);
	DeviceContext11->Flush();
	AlreadyClear_DX11 = false;
	return true;
}

bool OWLSpoutReceiver::Receive_DX12(FString name, UTextureRenderTarget2D* DestRenderTarget)
{
	if (Receiver_DX12->GetName() != name)
	{
		Receiver_DX12->ReleaseReceiver();
		Receiver_DX12->SetReceiverName(TCHAR_TO_ANSI(*name));
	}

	if (!Receiver_DX12->sendernames.FindSenderName(TCHAR_TO_ANSI(*name)))
	{
		if (!AlreadyClear_DX12)
		{
			// no texture to receive so we clear render target
			DestRenderTarget->UpdateResourceImmediate(true);
			AlreadyClear_DX12 = true;
		}
		return false;
	}
	
	if(!Receiver_DX12->ReceiveDX12Resource(&ReceivedResource_DX12))
	{
		UE_LOG(OWLSpoutLog, Error, TEXT("Failed to receive from sender: %s"), *name);
		return false;
	}
	
	if (Receiver_DX12->IsUpdated()) // If the incoming sender was resized, we need to remake our holding texture
	{
		if (ReceivedResource_DX12) ReceivedResource_DX12->Release();
		ReceivedResource_DX12 = nullptr;

		Receiver_DX12->CreateDX12texture(
			Receiver_DX12->GetD3D12device(),
			Receiver_DX12->GetSenderWidth(),
			Receiver_DX12->GetSenderHeight(),
			D3D12_RESOURCE_STATE_COPY_DEST,
			Receiver_DX12->GetSenderFormat(),
			&ReceivedResource_DX12);
	}
	
	ETextureRenderTargetFormat RT_Format = GetRTFormatFromDX(Receiver_DX12->GetSenderFormat());

	UpdateDestRenderTargetIfNeeded(Receiver_DX12->GetSenderWidth(), Receiver_DX12->GetSenderHeight(), RT_Format, DestRenderTarget);
	
	if (!DestRenderTarget)
	{
		UE_LOG(OWLSpoutLog, Error, TEXT("Frame skipped: Receiving Render Target is being modified: %s"), *name);
		return false; 
	}

	ENQUEUE_RENDER_COMMAND(RHICmdList)(
		[this, DestRenderTarget](FRHICommandListImmediate& RHICmdList)
		{
		//----------------------------------------------------------------------------------------
			// Would be better if we didn't have to create a new texture every frame, but could copy the contents directly
			// Have 2 methods, but cannot get the specific RHI ID2D12CommandList

			// Option 1: Copy Resource
			// FD3D12DynamicRHI* DynamicRHI = static_cast<FD3D12DynamicRHI*>(GDynamicRHI);
			// FD3D12Device* Device = static_cast<FD3D12Device*>(DynamicRHI->RHIGetNativeDevice());
			// FD3D12CommandListHandle Handle =  DynamicRHI->CreateCommandContext(Device, false, false)->CommandListHandle;
			// Handle->CopyResource(
			// 	static_cast<ID3D12Resource*>(DestRenderTarget->GetResource()->TextureRHI->GetNativeResource()),
			// 	ReceivedResourceDX12
			// 	);

			// Option 2: Copy Texture Region
			// CD3DX12_TEXTURE_COPY_LOCATION Dst(ReceivedResourceDX12, 0);
			// CD3DX12_TEXTURE_COPY_LOCATION Src(static_cast<ID3D12Resource*>(DestRenderTarget->GetResource()->TextureRHI->GetNativeResource()), 0);
			// RHICmdList.CopyTextureRegion(&Dst, 0, 0, 0, &Src, nullptr);
		//----------------------------------------------------------------------------------------

			if (ReceivedTextureFromResource_DX12.IsValid()) ReceivedTextureFromResource_DX12.SafeRelease();
			ReceivedTextureFromResource_DX12 = CreateRHITexture(ReceivedResource_DX12, EPixelFormat::PF_B8G8R8A8);

			RHICmdList.CopyToResolveTarget(
		ReceivedTextureFromResource_DX12,
		DestRenderTarget->Resource->GetTexture2DRHI(),
			FResolveParams());
		}
	);
	AlreadyClear_DX12 = false;
	return true;
}

void OWLSpoutReceiver::Close()
{
	Initialised = false;
	
	if (RHIType == OWLSpoutTools::ERHIType::D3D11)
	{
		Initialised = false;
		if (SenderNames_DX11 != nullptr)
		{
			delete SenderNames_DX11;
			SenderNames_DX11 = nullptr;

		}
		Initialised = false;
	}
	else if (RHIType == OWLSpoutTools::ERHIType::D3D12)
	{
		if (!Receiver_DX12) return;
		Receiver_DX12->ReleaseReceiver();
		Receiver_DX12->CloseDirectX12();
		
		if (ReceivedResource_DX12) ReceivedResource_DX12->Release();
		ReceivedResource_DX12 = nullptr;

		if (ReceivedTextureFromResource_DX12.IsValid())
		{
			ReceivedTextureFromResource_DX12.SafeRelease();
		}
	}
}

FString OWLSpoutReceiver::GetFirstAvailableName_DX12() const
{
	unsigned int dummyH, dummyW;
	HANDLE dummyHandle;
	char senderName[256];
	
	if (Receiver_DX12->GetSenderCount() <= 0) return FString("");
	Receiver_DX12->sendernames.GetSenderNameInfo(0, senderName, 256, dummyW, dummyH, dummyHandle);
	
	return FString(ANSI_TO_TCHAR(senderName));
}

FString OWLSpoutReceiver::GetFirstAvailableName_DX11() const
{
	unsigned int dummyH, dummyW;
	HANDLE dummyHandle;
	char senderName[256];
	
	if (SenderNames_DX11->GetSenderCount() <= 0) return FString("");
	SenderNames_DX11->GetSenderNameInfo(0, senderName, 256, dummyW, dummyH, dummyHandle);
	
	return FString(ANSI_TO_TCHAR(senderName));
}

ETextureRenderTargetFormat OWLSpoutReceiver::GetRTFormatFromDX(DXGI_FORMAT DxFormat)
{
	switch (DxFormat)
	{
		case DXGI_FORMAT_R8G8B8A8_UNORM_SRGB:
			return ETextureRenderTargetFormat::RTF_RGBA8_SRGB;
		case DXGI_FORMAT_R8G8B8A8_UINT:
			return ETextureRenderTargetFormat::RTF_RGBA8;
		case DXGI_FORMAT_R8G8B8A8_UNORM:
			return ETextureRenderTargetFormat::RTF_RGBA8;
		case DXGI_FORMAT_R16G16B16A16_FLOAT:
			return ETextureRenderTargetFormat::RTF_RGBA16f;
		case DXGI_FORMAT_R32G32B32A32_FLOAT:
			return ETextureRenderTargetFormat::RTF_RGBA32f;
		default:
			return ETextureRenderTargetFormat::RTF_RGBA8_SRGB;
	}
}

FTextureRHIRef OWLSpoutReceiver::CreateRHITexture(ID3D12Resource* Resource, EPixelFormat Format)
{
	FD3D12DynamicRHI* DynamicRHI = static_cast<FD3D12DynamicRHI*>(GDynamicRHI);
	ETextureCreateFlags TexCreateFlags = TexCreate_ShaderResource | TexCreate_RenderTargetable |  TexCreate_Shared;
	return DynamicRHI->RHICreateTexture2DFromResource(Format, TexCreateFlags, FClearValueBinding::None, (ID3D12Resource*)Resource).GetReference();
}

OWLSpoutReceiver::~OWLSpoutReceiver()
{
	Close();
}

// OWL SPOUT NAMES
//--------------------------------------------------

spoutSenderNames* OWLSpoutNames::SenderNames = nullptr;


TArray<FString> OWLSpoutNames::GetActiveSenderNames()
{
	if (!SenderNames)
	{
		SenderNames = new spoutSenderNames;
	}

	unsigned int dummyH, dummyW;
	HANDLE dummyHandle;
	int totalSenders = SenderNames->GetSenderCount();
	if (totalSenders == 0)
	{
		return TArray<FString>();
	}
	char senderName[256];

	TArray<FString> ActiveSenderNames;
	for (int32 i= 0; i < totalSenders; i++)
	{
		SenderNames->GetSenderNameInfo(i, senderName, 256, dummyW, dummyH, dummyHandle);
		ActiveSenderNames.Add(FString(ANSI_TO_TCHAR(senderName)));
	}

	return ActiveSenderNames;
}

void OWLSpoutNames::Cleanup()
{
	if (SenderNames)
	{
		delete SenderNames;
	}
}