// Copyright Off World Live Limited, 2020-2021. All rights reserved.

#include "USpout/Public/OWLSpoutSender.h"
#include "SpoutModule.h"
#include "SpoutDX.h"
#include "SpoutDX12/SpoutDX12.h"


void OWLSpoutSender::SendRenderTarget(FString name, UTextureRenderTarget2D* textureRenderTarget2D)
{
	if (FailedToInitialise) return;

	if(!Initialised)
	{
		FString rhiString = GDynamicRHI->GetName();
		RHIType = OWLSpoutTools::StringToRHIType(rhiString);

		if (RHIType == OWLSpoutTools::ERHIType::D3D11 || RHIType == OWLSpoutTools::ERHIType::D3D12)
		{
			InitDX();
		}
		else
		{
			FailedToInitialise = true;
			UE_LOG(OWLSpoutLog, Warning, TEXT("%s is incompatible with the Spout interface. Please use D3D11 or D3D12."), *rhiString);
		}
	}

	Send(name, textureRenderTarget2D);
}


bool OWLSpoutSender::InitDX()
{
	if(Initialised) return true;
	
	if (RHIType == OWLSpoutTools::ERHIType::D3D11)
	{
		ENQUEUE_RENDER_COMMAND(RHICmdList)(
[this](FRHICommandListImmediate& RHICmdList)
		{
			if(!SenderNames_DX11) SenderNames_DX11 = new spoutSenderNames;
			Device11 = static_cast<ID3D11Device*>(GDynamicRHI->RHIGetNativeDevice());
			Device11->GetImmediateContext(&DeviceContext11);
			Initialised = true;
		});
	}
	else if (RHIType == OWLSpoutTools::ERHIType::D3D12)
	{
		if (!Sender_DX12) Sender_DX12 = new spoutDX12;
		
		if (ID3D12Device* device = static_cast<ID3D12Device*>(GDynamicRHI->RHIGetNativeDevice()))
		{
			Initialised = Sender_DX12->OpenDirectX12(device);
		}
	}

	return Initialised;
}

void OWLSpoutSender::Send(FString name, UTextureRenderTarget2D* srcRenderTarget)
{
	if (srcRenderTarget == nullptr
		|| srcRenderTarget->Resource == nullptr
		|| srcRenderTarget->Resource->TextureRHI == nullptr
		|| srcRenderTarget->Resource->TextureRHI->GetTexture2D() == nullptr
		|| !Initialised)
	{
		// this is a safety check in case user is regenerating the resource
		// for example this happens while resizing
		return;
	}

	const FRHITexture2D* Src = srcRenderTarget->Resource->GetTexture2DRHI();

	if (RHIType == OWLSpoutTools::D3D11)
	{
		ENQUEUE_RENDER_COMMAND(RHICmdList)(
		[this, Src, name](FRHICommandListImmediate& RHICmdList)
		{
			if(!Initialised) return;
			
			D3D11_TEXTURE2D_DESC desc;
			ID3D11Texture2D* NativeTex = (ID3D11Texture2D*)Src->GetNativeResource();
			NativeTex->GetDesc(&desc);
			unsigned long SourceFormat = desc.Format;
			if (SourceFormat == DXGI_FORMAT_B8G8R8A8_TYPELESS) SourceFormat = DXGI_FORMAT_B8G8R8A8_UNORM;
			unsigned int SourceWidth = desc.Width;
			unsigned int SourceHeight = desc.Height;
			
			unsigned int SenderWidth;
			unsigned int SenderHeight;
			unsigned long SenderFormat;

			// Create new share texture if we don't already have one
			if(!SenderNames_DX11->CheckSender(TCHAR_TO_ANSI(*name), SenderWidth, SenderHeight, SenderHandle_DX11, SenderFormat))
			{
				SenderFormat = SourceFormat;
				SenderWidth = SourceWidth;
				SenderHeight = SourceHeight;
				if(!CreateSharedTexture_DX11(SourceWidth, SourceHeight, SourceFormat,SenderHandle_DX11, SendingTexture_DX11))
				{
					UE_LOG(OWLSpoutLog, Warning, TEXT("Failed to create shared texture for sender: %s"), *name);
					return;
				}
				if (!SenderNames_DX11->CreateSender(TCHAR_TO_ANSI(*name), SenderWidth, SenderHeight, SenderHandle_DX11, SenderFormat))
				{
					UE_LOG(OWLSpoutLog, Error, TEXT("Failed while creating sender DX11 with sender name : %s"), *name);
					return;
				}
			}
			
			// Check is texture needs to be updated
			if(SenderWidth != SourceWidth
				|| SenderHeight != SourceHeight
				|| SenderFormat != SourceFormat)
			{
				SendingTexture_DX11->Release();
				SendingTexture_DX11 = nullptr;
				
				SenderFormat = SourceFormat;
				SenderWidth = SourceWidth;
				SenderHeight = SourceHeight;
				if(!CreateSharedTexture_DX11(SourceWidth, SourceHeight, SourceFormat,SenderHandle_DX11, SendingTexture_DX11))
				{
					UE_LOG(OWLSpoutLog, Warning, TEXT("Failed to update shared texture for sender: %s"), *name);
					return;
				}
				SenderNames_DX11->UpdateSender(TCHAR_TO_ANSI(*name), SenderWidth, SenderHeight, SenderHandle_DX11, SenderFormat);
			}
			
			DeviceContext11->CopyResource(SendingTexture_DX11, NativeTex);
			DeviceContext11->Flush();
			SenderName_DX11 = name;
		});
	}
	else if (RHIType == OWLSpoutTools::D3D12)
	{
		if (Sender_DX12->GetName() != name)
		{
			Sender_DX12->ReleaseSender();
			Sender_DX12->SetSenderName(TCHAR_TO_ANSI(*name));
		}
		ENQUEUE_RENDER_COMMAND(RHICmdList)(
			[this, Src](FRHICommandListImmediate& RHICmdList)
			{
				if (!Sender_DX12) return;
				
				// TODO: it is possible that we will only need to wrap it once (or once every resize/ pixel format change) rather than every frame - worth double checking
				ID3D11Resource* WrappedDX11SrcResource = nullptr;
				ID3D12Resource* NativeTex = static_cast<ID3D12Resource*>(Src->GetNativeResource());

				Sender_DX12->WrapDX12Resource(NativeTex, &WrappedDX11SrcResource, D3D12_RESOURCE_STATE_RENDER_TARGET);
				if (WrappedDX11SrcResource)
				{
					Sender_DX12->SendDX11Resource(WrappedDX11SrcResource);
				}
			});
	}
}

OWLSpoutSender::~OWLSpoutSender()
{
	Close();
}

void OWLSpoutSender::Close()
{
	Initialised = false;
	
	if (RHIType == OWLSpoutTools::D3D11)
	{
		ENQUEUE_RENDER_COMMAND(RHICmdList)(
[this](FRHICommandListImmediate& RHICmdList)
		{
			if(SendingTexture_DX11)
			{
				SendingTexture_DX11->Release();
				SendingTexture_DX11 = nullptr;
			}
			if (SenderNames_DX11 != nullptr)
			{
				SenderNames_DX11->ReleaseSenderName(TCHAR_TO_ANSI(*SenderName_DX11));
				delete SenderNames_DX11;
				SenderNames_DX11 = nullptr;

			}
		});
	}
	else if (RHIType == OWLSpoutTools::D3D12)
	{
		if (!Sender_DX12) return;
		Sender_DX12->ReleaseSender();
		Sender_DX12->CloseDirectX12();
	}
}

bool OWLSpoutSender::CreateSharedTexture_DX11(const unsigned Width, const unsigned Height, const unsigned long Format,
	HANDLE& Handle, ID3D11Texture2D*& Texture)
{
	ID3D11Texture2D* NewSharedTexture = nullptr; 
	DXGI_FORMAT ActualFormat = (DXGI_FORMAT)Format;
	if (Format == 0 || Format == 21 || Format == 22) ActualFormat = DXGI_FORMAT_B8G8R8A8_UNORM;
	D3D11_TEXTURE2D_DESC desc;
	ZeroMemory(&desc, sizeof(desc));
	desc.Width = Width;
	desc.Height = Height;
	desc.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
	desc.MiscFlags = D3D11_RESOURCE_MISC_SHARED; 
	desc.CPUAccessFlags		= 0;	
	desc.Format				= ActualFormat;
	desc.Usage				= D3D11_USAGE_DEFAULT;
	desc.SampleDesc.Quality = 0;
	desc.SampleDesc.Count	= 1;
	desc.MipLevels			= 1;
	desc.ArraySize			= 1;

	HRESULT res = Device11->CreateTexture2D(&desc, NULL, &NewSharedTexture);
	
	if (FAILED(res))
	{
		UE_LOG(OWLSpoutLog, Error, TEXT("SharedDX11Texture creation failed"));
		return false;
	}
	
	IDXGIResource* DummyResource(NULL);
	if(FAILED(NewSharedTexture->QueryInterface( __uuidof(IDXGIResource), (void**)&DummyResource)))
	{
		UE_LOG(OWLSpoutLog, Error, TEXT("SharedDX11Texture QueryInterface error"));
		return false;
	}
	
	DummyResource->GetSharedHandle(&Handle); 
	DummyResource->Release();
	Texture = NewSharedTexture;
	return true;
}
